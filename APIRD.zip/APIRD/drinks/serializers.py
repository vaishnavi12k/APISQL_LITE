from rest_framework import serializers
from .models import Drinks

#Seralization/DeS

class DrinkSerializer(serializers.ModelSerializer):
    class Meta:
        model = Drinks
        fields = "__all__"