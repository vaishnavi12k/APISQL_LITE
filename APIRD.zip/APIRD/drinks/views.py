from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from rest_framework.decorators import api_view
from .models import Drinks
from rest_framework import status

# Create your views here.

# function views 
## Operation => HTTP Method
## get ,post ,put,delete =>(CRUD)
## Decorator => adding functinaltiy(usacases) to other functions 

# post = insert 
# get = fetch 
from rest_framework.response import Response
from .serializers import DrinkSerializer      

@api_view(['GET', 'POST'])
def drinks_list(request):
    if request.method == "GET":
        drinks = Drinks.objects.all() ##rows =>(ORM) Python object =>JSON
        seralizer = DrinkSerializer(drinks,many=True)
        return Response(seralizer.data)
    if request.method == "POST":
        ## request (data)
        ## json -> po (des)
        ## save => po->table row (orm)=save db
        serializer = DrinkSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

# put ,delete 
# put 
# id => which row to update (pk:integer)
# Drinks.objects.find(pk=id)
#  updatedata
#  seralization 

def display(request):
     return HttpResponse("Home Page")

@api_view(['GET', 'PUT', 'DELETE'])
def drink_detail(request, id):
    try:
        drink = Drinks.objects.get(pk=id)
        # what to update,what to get
    except Drinks.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    if request.method == "GET":
        serializer = DrinkSerializer(drink)
        return Response(serializer.data) 
    elif request.method == "PUT":
        serializer = DrinkSerializer(drink, data=request.data)
        # data -> json -> object 
        # drink => object(id=1)
        # drink object which is hving id of 1 
        if serializer.is_valid():
            serializer.save() #database refelect
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == "DELETE":
        drink.delete()
        return Response("deleted successfully")

   